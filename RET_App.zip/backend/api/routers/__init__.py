# Router module imports for FastAPI application
# This allows clean imports: from api.routers import auth_router

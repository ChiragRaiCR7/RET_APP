<template>
  <div>
    <div 
      class="file-upload-zone" 
      @dragover.prevent="dragging = true" 
      @dragleave.prevent="dragging = false" 
      @drop.prevent="onDrop" 
      :class="{ dragging }" 
      @click="open"
    >
      <div class="file-upload-icon" aria-hidden="true">📦</div>
      <div><strong>Drop ZIP or XML files here, or click to upload</strong></div>
      <div class="form-hint">Supports ZIP archives and individual XML files. Max 200MB. We'll scan and show a preview.</div>
    </div>
    
    <input 
      ref="input" 
      type="file" 
      multiple 
      @change="onFiles" 
      style="display:none" 
      accept=".zip,.xml,application/zip,text/xml,application/xml" 
    />
    
    <div v-if="files.length" style="margin-top: var(--space-md)">
      <div v-for="(f, i) in files" :key="i" class="info-item">
        <div style="display:flex; justify-content:space-between;">
          <div>
            <div style="font-weight:800">{{ f.name }}</div>
            <div class="form-hint">{{ prettySize(f.size) }} • {{ f.type || 'zip' }}</div>
          </div>
          <div style="display:flex; gap:8px; align-items:center">
            <button 
              class="btn btn-sm btn-primary" 
              @click.stop="scanFile(f)"
              :disabled="scanning"
            >
              <span v-if="scanning" class="spinner" style="margin-right:4px"></span>
              {{ scanning ? 'Scanning...' : 'Scan' }}
            </button>
            <button class="btn btn-sm" @click.stop="remove(i)">Remove</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Scan Results -->
    <div v-if="scanResults" style="margin-top: var(--space-lg)">
      <div class="enterprise-card">
        <h4 class="card-title">📊 Scan Results</h4>
        
        <div class="metric-container">
          <div class="metric-card">
            <div class="metric-value">{{ scanResults.xml_count }}</div>
            <div class="metric-label">XML Files</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">{{ scanResults.group_count }}</div>
            <div class="metric-label">Groups Found</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">{{ prettySize(scanResults.summary.totalSize) }}</div>
            <div class="metric-label">Total Size</div>
          </div>
        </div>

        <!-- Groups Table -->
        <div style="margin-top: var(--space-lg)">
          <h5 class="card-title">Groups Detected</h5>
          <table class="data-table" role="table">
            <thead>
              <tr>
                <th>Group Name</th>
                <th>Files</th>
                <th>Size</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="group in scanResults.groups" :key="group.name">
                <td><strong>{{ group.name }}</strong></td>
                <td>{{ group.file_count }}</td>
                <td>{{ prettySize(group.size) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Error Display -->
    <div v-if="error" style="margin-top: var(--space-md); padding: var(--space-md); background: #fee; color: #c33; border-radius: 4px;">
      <strong>Error:</strong> {{ error }}
      <button 
        @click="error = ''"
        style="float: right; background: none; border: none; cursor: pointer; font-size: 16px;"
      >
        ×
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import api from '@/utils/api'

const input = ref(null)
const files = ref([])
const dragging = ref(false)
const scanning = ref(false)
const scanResults = ref(null)
const error = ref('')

// Define emits - 'files-added' for raw files, 'uploaded'/'scanned' for scan results
const emit = defineEmits(['uploaded', 'scanned', 'files-added'])

function open() {
  input.value?.click()
}

function onFiles(e) {
  const list = Array.from(e.target.files || [])
  files.value.push(...list)
  error.value = ''
  // Emit raw files immediately so parent can track them
  emit('files-added', list)
}

function onDrop(e) {
  dragging.value = false
  const list = Array.from(e.dataTransfer.files || [])
  files.value.push(...list)
  error.value = ''
  // Emit raw files immediately so parent can track them
  emit('files-added', list)
}

function remove(i) {
  files.value.splice(i, 1)
}

function prettySize(n) {
  if (!n) return '-'
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / (1024 * 1024)).toFixed(1)} MB`
}

async function scanFile(file) {
  const data = new FormData()
  data.append('file', file)
  scanning.value = true
  error.value = ''
  
  try {
    const resp = await api.post('/conversion/scan', data, { 
      headers: { 'Content-Type': 'multipart/form-data' } 
    })
    
    scanResults.value = resp.data
    emit('scanned', resp.data)
    emit('uploaded', {
      sessionId: resp.data.session_id,
      groups: resp.data.groups,
      xmlCount: resp.data.xml_count,
    })
  } catch (e) {
    error.value = e.response?.data?.detail || e.response?.data?.message || e.message || 'Unknown error'
    console.error('Scan error:', e)
  } finally {
    scanning.value = false
  }
}
</script>

<style scoped>
.file-upload-zone {
  border: 2px dashed var(--border-medium);
  border-radius: var(--radius-lg);
  padding: var(--space-xl) var(--space-lg);
  text-align: center;
  cursor: pointer;
  transition: all var(--transition-base);
  background: var(--surface-base);
}

.file-upload-zone:hover {
  border-color: var(--brand-primary);
  background: var(--brand-subtle);
}

.file-upload-zone.dragging {
  border-color: var(--brand-primary);
  background: var(--brand-subtle);
  border-style: solid;
}

.file-upload-icon {
  font-size: 3rem;
  margin-bottom: var(--space-md);
}

.info-item {
  background: var(--surface-elevated);
  border: 1px solid var(--border-light);
  border-radius: var(--radius-md);
  padding: var(--space-md);
  margin-bottom: var(--space-sm);
}

.metric-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: var(--space-md);
  margin-bottom: var(--space-lg);
}

.metric-card {
  background: var(--surface-elevated);
  border: 1px solid var(--border-light);
  border-radius: var(--radius-md);
  padding: var(--space-md);
  text-align: center;
}

.metric-value {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--brand-primary);
}

.metric-label {
  font-size: 0.85rem;
  color: var(--text-tertiary);
  margin-top: var(--space-xs);
}

.spinner {
  display: inline-block;
  width: 14px;
  height: 14px;
  border: 2px solid transparent;
  border-top-color: currentColor;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.spinner {
  display: inline-block;
  width: 12px;
  height: 12px;
  border: 2px solid #f3f3f3;
  border-top: 2px solid #007bff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
